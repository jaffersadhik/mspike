#!/bin/sh

aclocal
autoconf
